﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace todoo
{
    /// <summary>
    /// Логика взаимодействия для Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {
        private readonly string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=B:\Database2.mdb;";
        public Window3()
        {
            InitializeComponent();
        }


        private void Adata_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {


        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {

            todoo.DataSet1 dataSet1 = ((todoo.DataSet1)(this.FindResource("dataSet1")));
            // Загрузить данные в таблицу СтатусыЗаказов. Можно изменить этот код как требуется.
            todoo.DataSet1TableAdapters.СтатусыЗаказовTableAdapter dataSet1СтатусыЗаказовTableAdapter = new todoo.DataSet1TableAdapters.СтатусыЗаказовTableAdapter();
            dataSet1СтатусыЗаказовTableAdapter.Fill(dataSet1.СтатусыЗаказов);
            System.Windows.Data.CollectionViewSource статусыЗаказовViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("статусыЗаказовViewSource")));
            статусыЗаказовViewSource.View.MoveCurrentToFirst();
        }

        private void статусыЗаказовDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
